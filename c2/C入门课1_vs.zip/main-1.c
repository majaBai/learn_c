/*
 第一个项目
    用 A D 可以左右移动的蓝色小球
 
 新语法
    break
 
 作业
    加上 W S 上下移动蓝色小球的功能
*/
#include "kbc.h"



int
main(void) {
    // 创建一个窗口
    // 参数是 宽 高
    kbcWindowNew(800, 600);

    
    // 变量 x, 用于表示圆形的 x
    int x = 100;

    // 无限循环, 这样程序就不会停止
    // 这个循环每 1/60 秒执行一次
    // 由下面的 kbcWaitFrame 函数保证
    while(1) {
        // 如果 esc 是被按下的状态。 break 会退出循环，程序自然结束
        if (kbcKeyIsDown(KEY_ESCAPE)) {
            break;
        }
        
        // 检查 A D 是否按下，改变 x
        if (kbcKeyIsDown(KEY_A)) {
            x -= 10;
        }
        if (kbcKeyIsDown(KEY_D)) {
            x += 10;
        }

        
        // 这个函数会用白色清空窗口
        // 这样上一次循环画的所有内容都会被擦除
        kbcWindowClear();
        
        
        // 画一个圆
        // 4 个参数分别是  圆心x 圆心y 圆半径 颜色
        kbcDrawCircle(x, 500, 10, kbcColorBlue);

        
        // kbcWaitFrame 会让程序等待一段时间后再继续运行
        // 确保每秒只运行 60 次循环
        kbcWaitFrame();
    }

    return 0;
}
